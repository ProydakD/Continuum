"""E008 evaluation-only correction: private SQLite reads and guarded decision memoization.

Frozen project modules, assignment criteria, raw audits and scorers remain unchanged.
This supplement must be separately identified in the final report.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
from pathlib import Path
import shutil
import tempfile

from research import e008_evaluate as frozen
from research import e008_measurements as measurements
from research.e008_locks import read

FROZEN_DECISIONS = frozen.ReadOnlyDecisions
FROZEN_SNAPSHOT = measurements.snapshot


def sqlite_inputs(path):
    path = Path(path).resolve(strict=True)
    paths = [Path(str(path) + suffix) for suffix in ("", "-wal", "-shm", "-journal")]
    return {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.exists()}


def private_snapshot(path):
    """Use all existing SQLite inputs, including WAL; never query the sealed original."""
    path = Path(path).resolve(strict=True)
    before = sqlite_inputs(path)
    with tempfile.TemporaryDirectory(prefix="e008-readonly-sqlite-") as directory:
        target = Path(directory) / path.name
        for source, expected in before.items():
            copied = Path(directory) / source.name
            shutil.copyfile(source, copied)
            if hashlib.sha256(copied.read_bytes()).hexdigest() != expected:
                raise PermissionError("SQLite input changed while copying")
        result = FROZEN_SNAPSHOT(target)
        if sqlite_inputs(path) != before:
            raise PermissionError("sealed SQLite inputs changed during private read")
        return result


class CachedReadOnlyDecisions(FROZEN_DECISIONS):
    """Cache only fully reconstructed locks; recheck inputs and stored lock on every use."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._decision_cache = {}
        self.cache_counts = {"calibration": 0, "protocol": 0}

    def _cached_decision(self, name, reconstruct):
        self._check_binding()
        if name not in self._decision_cache:
            self._decision_cache[name] = deepcopy(reconstruct())
            self.cache_counts[name] += 1
        value = self._decision_cache[name]
        if read(self.study / "locks" / (name + ".json")) != value:
            raise PermissionError("cached decision differs from frozen stored lock")
        return deepcopy(value)

    def calibration_lock(self):
        return self._cached_decision("calibration", super().calibration_lock)

    def protocol_lock(self):
        return self._cached_decision("protocol", super().protocol_lock)


@contextmanager
def corrected_dependencies():
    """Process-local, explicit dependency injection, restored even on failure."""
    if frozen.ReadOnlyDecisions is not FROZEN_DECISIONS or measurements.snapshot is not FROZEN_SNAPSHOT:
        raise RuntimeError("unexpected preexisting evaluator override")
    frozen.ReadOnlyDecisions = CachedReadOnlyDecisions
    measurements.snapshot = private_snapshot
    try:
        yield
    finally:
        frozen.ReadOnlyDecisions = FROZEN_DECISIONS
        measurements.snapshot = FROZEN_SNAPSHOT
