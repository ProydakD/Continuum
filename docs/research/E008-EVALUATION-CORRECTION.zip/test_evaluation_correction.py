import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

PROJECT=Path(r"C:\Users\User\Documents\ChatGPT\ContinuumResearch\project")
sys.path.insert(0,str(PROJECT))
from research.common import ROOT,digest
from research.e008_locks import read,file_manifest
from research import e008_measurements as measurements
from research import e008_evaluate as frozen
from e008_evaluation_correction import private_snapshot,CachedReadOnlyDecisions,corrected_dependencies,FROZEN_SNAPSHOT,FROZEN_DECISIONS


def sealed_copy(identity,destination):
    source=ROOT/'runs/e008-series-001/units'/identity
    outcome=read(source/'outcome.json')
    for name in [*outcome['files'],'outcome.json']:
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/name,target)
    assert file_manifest(destination)==outcome['files']


class CorrectionTests(unittest.TestCase):
    def test_reproduce_failed_WAL_read_sidecars_and_fixed_read_preserves_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);baseline=root/'baseline';fixed=root/'fixed'
            sealed_copy('j00032',baseline);sealed_copy('j00032',fixed)
            before=file_manifest(baseline);expected=file_manifest(fixed)
            old=measurements.context_measurements(baseline)
            added=set(file_manifest(baseline))-set(before)
            self.assertEqual(added,{'state/continuum.sqlite3-wal','state/continuum.sqlite3-shm'})
            self.assertEqual((baseline/'state/continuum.sqlite3-wal').stat().st_size,0)
            with corrected_dependencies():
                new=measurements.context_measurements(fixed)
            self.assertEqual(file_manifest(fixed),expected)
            self.assertEqual(old['retained_file_bytes']-new['retained_file_bytes'],32768)
            self.assertEqual({k:v for k,v in old.items() if k!='retained_file_bytes'},
                             {k:v for k,v in new.items() if k!='retained_file_bytes'})
            self.assertEqual(new['retained_file_bytes'],sum(p.stat().st_size for p in fixed.rglob('*') if p.is_file()))

    def test_completed_context_measurements_match_frozen_reader(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);baseline=root/'baseline';fixed=root/'fixed'
            sealed_copy('j00001',baseline);sealed_copy('j00001',fixed)
            before=file_manifest(fixed);old=measurements.context_measurements(baseline)
            with corrected_dependencies():new=measurements.context_measurements(fixed)
            self.assertEqual(new,old);self.assertEqual(file_manifest(fixed),before)

    def test_nonempty_WAL_is_read_not_ignored(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'archive.sqlite3'
            db=sqlite3.connect(path)
            try:
                db.execute('PRAGMA journal_mode=WAL')
                db.execute('CREATE TABLE tasks(result TEXT)')
                db.execute('INSERT INTO tasks VALUES (?)',('{}',))
                db.execute('CREATE TABLE knowledge_objects(sha256 TEXT,content BLOB)')
                for name in ('events','claims','evidence'):db.execute('CREATE TABLE '+name+'(id TEXT)')
                db.commit()
                self.assertGreater(Path(str(path)+'-wal').stat().st_size,0)
                expected=FROZEN_SNAPSHOT(path)
                before={p.name:digest(p) for p in Path(directory).iterdir()}
                self.assertEqual(private_snapshot(path),expected)
                self.assertEqual({p.name:digest(p) for p in Path(directory).iterdir()},before)
            finally:db.close()

    def test_copy_detects_original_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            unit=Path(directory)/'unit';sealed_copy('j00032',unit);path=unit/'state/continuum.sqlite3'
            def changed(copied):
                value=FROZEN_SNAPSHOT(copied)
                path.write_bytes(path.read_bytes()+b'changed')
                return value
            with patch('e008_evaluation_correction.FROZEN_SNAPSHOT',changed):
                with self.assertRaises(PermissionError):private_snapshot(path)

    def test_cache_reconstructs_once_and_returns_detached_values(self):
        with tempfile.TemporaryDirectory() as directory:
            store=self.store(Path(directory));calls=[]
            def compute():calls.append(1);return {'value':[1]}
            first=store._cached_decision('calibration',compute);first['value'].append(2)
            self.assertEqual(store._cached_decision('calibration',compute),{'value':[1]})
            self.assertEqual(calls,[1]);self.assertEqual(store.cache_counts['calibration'],1)
            self.assertEqual(store.bindings_checked,2)

    def test_cache_rejects_changed_or_missing_stored_lock(self):
        with tempfile.TemporaryDirectory() as directory:
            store=self.store(Path(directory));store._cached_decision('calibration',lambda:{'value':[1]})
            path=store.study/'locks/calibration.json';path.write_text('{"value":[2]}',encoding='utf-8')
            with self.assertRaises(PermissionError):store._cached_decision('calibration',lambda:None)
            path.unlink()
            with self.assertRaises(FileNotFoundError):store._cached_decision('calibration',lambda:None)

    def test_cache_still_checks_input_binding_on_hit(self):
        with tempfile.TemporaryDirectory() as directory:
            store=self.store(Path(directory));store._cached_decision('calibration',lambda:{'value':[1]})
            def fail():raise PermissionError('input changed')
            store._check_binding=fail
            with self.assertRaises(PermissionError):store._cached_decision('calibration',lambda:None)

    def test_dependency_override_is_scoped_and_restored_on_failure(self):
        with self.assertRaises(ValueError):
            with corrected_dependencies():
                self.assertIs(frozen.ReadOnlyDecisions,CachedReadOnlyDecisions)
                self.assertIs(measurements.snapshot,private_snapshot)
                raise ValueError('test')
        self.assertIs(frozen.ReadOnlyDecisions,FROZEN_DECISIONS)
        self.assertIs(measurements.snapshot,FROZEN_SNAPSHOT)

    def test_nested_override_is_rejected(self):
        with corrected_dependencies():
            with self.assertRaises(RuntimeError):
                with corrected_dependencies():pass

    @staticmethod
    def store(directory):
        store=object.__new__(CachedReadOnlyDecisions);store.study=directory
        (directory/'locks').mkdir();(directory/'locks/calibration.json').write_text('{"value":[1]}',encoding='utf-8')
        store._decision_cache={};store.cache_counts={'calibration':0,'protocol':0};store.bindings_checked=0
        def check():store.bindings_checked+=1
        store._check_binding=check
        return store

if __name__=='__main__':unittest.main(verbosity=2)
