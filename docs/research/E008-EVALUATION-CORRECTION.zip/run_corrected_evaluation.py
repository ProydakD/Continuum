"""Run the frozen scientific evaluator with an explicitly identified evaluation supplement."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

PROJECT = Path(r"C:\Users\User\Documents\ChatGPT\ContinuumResearch\project")
sys.path.insert(0, str(PROJECT))
from research.common import ROOT, digest
from research.e003 import implementation_hashes
from research.e008_evaluate import evaluate
from research.e008_integrity import reference_binding
from research.e008_live import controller_lock, verified_gold
from research.e008_locks import read, write_once
from e008_evaluation_correction import corrected_dependencies
from quarantine_observer_sidecars import manifest

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
ART = STAGE.parent
STUDY = ROOT / 'runs/e008-series-001'
BUNDLE = PROJECT / 'docs/research/E008-EVALUATION-CORRECTION.zip'
OUTPUT = ART / 'E008-FINAL-EVALUATION-002.json'


def event(phase, **values):
    print(json.dumps({'at': time.time(), 'phase': phase, **values}), flush=True)


def main():
    started = time.time()
    assert not OUTPUT.exists()
    assert not os.environ.get('API_KEY') and not os.environ.get('OPENAI_API_KEY')
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT).decode().strip()
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=PROJECT)
    bundle_sha = digest(BUNDLE)
    with zipfile.ZipFile(BUNDLE) as bundle:
        names = bundle.namelist()
        assert names and all(Path(name).name == name for name in names)
        assert all(bundle.read(name) == (HERE / name).read_bytes() for name in names)
    supplement_sources = {name: digest(HERE / name) for name in names}
    implementation = implementation_hashes()
    assert implementation == read(PROJECT / 'docs/research/E008-SOCKET-RESUMPTION.json')['implementation_hashes']
    recovery_path = STAGE / 'FINAL-EVALUATION-OBSERVER-RECOVERY-001.json'
    recovery = read(recovery_path)
    assert recovery['pass'] and recovery['sealed_file_bytes_changed'] == 0
    fixture_path = HERE / 'FULL-FIXTURE-EQUIVALENCE-002.json'
    fixture = read(fixture_path)
    assert fixture['pass'] and fixture['reports_equal_all_fields'] and fixture['original_fixture_unchanged']
    assert fixture['supplement_sha256'] == supplement_sources['e008_evaluation_correction.py']
    ledger = [json.loads(line) for line in (ART / 'command-ledger.jsonl').read_text('utf-8').splitlines()]
    tests = [row for row in ledger if row.get('label') in
             ('evaluation-correction-unit-001', 'evaluation-correction-fixture-002')]
    assert len(tests) == 2 and all(row['exit_status'] == 0 for row in tests)
    with controller_lock(STUDY):
        event('verify_restored_sealed_inventory')
        before = manifest(STUDY)
        assert before == read(STAGE / 'E008-SERIES-TERMINAL-001.json')['raw_manifest']
        corpus_path = ART / 'CANDIDATE-CORPUS.json'
        corpus = read(corpus_path)
        event('verify_existing_gold')
        _, gold = verified_gold(STUDY / 'gold', corpus, implementation)
        actual = read(STUDY / 'oracle.json')['worlds']
        known = {w['id']: w for w in corpus['worlds']}
        assert all(known.get(w['id']) == w for w in actual)
        event('recheck_existing_cold_REF_no_workers')
        reference = reference_binding(ROOT / 'runs/e008-reference-series-001', corpus_path,
                                      STUDY / 'gold/manifest.json', corpus['worlds'], gold)
        event('full_raw_audit_and_registered_statistics', positions=3426, bootstrap_draws=10000)
        with corrected_dependencies():
            report = evaluate(STUDY, {w['id']: gold[w['id']] for w in actual}, reference=reference,
                              bootstrap_samples=10000,
                              amendment_path=PROJECT / 'docs/research/E008-MODEL-AMENDMENT.json',
                              resumption_path=PROJECT / 'docs/research/E008-SOCKET-RESUMPTION.json')
        event('verify_complete_inputs_unchanged')
        assert manifest(STUDY) == before
        assert implementation_hashes() == implementation
        assert digest(BUNDLE) == bundle_sha
        assert {name: digest(HERE / name) for name in names} == supplement_sources
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT).decode().strip() == commit
        assert report['evaluated_positions'] == 3426 and report['scientific_inference'] and not report['fixture']
        report['evaluation_supplement'] = {
            'identity': 'E008 evaluation correction 001', 'started': started, 'ended': time.time(),
            'commit': commit, 'bundle': str(BUNDLE), 'bundle_sha256': bundle_sha,
            'sources': supplement_sources, 'original_failed_evaluation': str(STAGE / 'final-evaluation-001/command.json'),
            'original_failed_evaluation_sha256': digest(STAGE / 'final-evaluation-001/command.json'),
            'recovery': str(recovery_path), 'recovery_sha256': digest(recovery_path),
            'fixture_equivalence': str(fixture_path), 'fixture_equivalence_sha256': digest(fixture_path),
            'literal_checks': tests,
            'changes': ['resource snapshot reads exact private copies of SQLite DB and ALL existing sidecars',
                        'memoize independently reconstructed calibration/protocol locks; recheck binding and stored lock on every access'],
            'sealed_files_unchanged': len(before), 'raw_hashes_rechecked_after_evaluation': True,
            'scientific_functions_and_execution_sources_unchanged': True,
            'new_model_requests': 0, 'new_REF_workers': 0,
            'limitation': 'The effective evaluator is supplemented, not identical to original run001. '
                          'Resource retained bytes exclude observer-created files. No hypothesis, denominator, '
                          'statistical threshold, raw audit, assignment or historical outcome was changed.'}
        write_once(OUTPUT, report)
        assert read(OUTPUT) == report
        event('report_written_and_reopened', output=str(OUTPUT), sha256=digest(OUTPUT),
              positions=3426, statuses=report['statuses'], research_complete=False)


if __name__ == '__main__':
    main()
