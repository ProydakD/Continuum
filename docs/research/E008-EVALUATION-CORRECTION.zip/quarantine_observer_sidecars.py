"""Preserve only proven evaluator-created additions, restoring the sealed inventory."""
import json
import subprocess
import sys
import time
from pathlib import Path

PROJECT = Path(r"C:\Users\User\Documents\ChatGPT\ContinuumResearch\project")
sys.path.insert(0, str(PROJECT))
from research.common import ROOT, digest
from research.e008_live import controller_lock
from research.e008_locks import read, write_once

STAGE = Path(__file__).resolve().parent.parent
STUDY = (ROOT / 'runs/e008-series-001').resolve(strict=True)
ARCHIVE = STAGE / 'final-evaluation-001/observer-created-sqlite-sidecars'


def manifest(root):
    result = {}
    for path in root.rglob('*'):
        if path.is_file() and path.name != 'controller.lock':
            if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
                raise PermissionError('unexpected nonlocal evidence path')
            result[path.relative_to(root).as_posix()] = digest(path)
    return result


def main():
    started = time.time()
    terminal_path = STAGE / 'E008-SERIES-TERMINAL-001.json'
    failure_path = STAGE / 'FINAL-EVALUATION-ERROR-MANIFEST-001.json'
    terminal, failure = read(terminal_path), read(failure_path)
    command = read(STAGE / 'final-evaluation-001/command.json')
    assert command['exit_status'] == 1 and 'sealed context evidence changed' in command['stderr']
    assert not failure['original_files_changed'] and len(failure['added_files']) == 322
    assert not ARCHIVE.exists()
    argv = ['powershell', '-NoProfile', '-Command',
            "Get-CimInstance Win32_Process | Where-Object {$_.Name -match 'python' -and $_.CommandLine -match 'research.e008_(evaluate|live).*e008-series-001'} | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"]
    process = subprocess.run(argv, capture_output=True, text=True, encoding='utf-8')
    assert process.returncode == 0 and not process.stdout.strip()
    with controller_lock(STUDY):
        before = manifest(STUDY)
        expected = terminal['raw_manifest']
        additions = set(before) - set(expected)
        assert additions == set(failure['added_files'])
        assert all(before.get(name) == sha for name, sha in expected.items())
        moves = []
        for name in sorted(additions):
            path = (STUDY / name).resolve(strict=True)
            destination = (ARCHIVE / name).resolve()
            parts = Path(name).parts
            assert path.is_relative_to(STUDY) and destination.is_relative_to(ARCHIVE.resolve())
            assert len(parts) == 4 and parts[0] == 'units' and parts[2] == 'state'
            assert parts[3] in ('continuum.sqlite3-wal', 'continuum.sqlite3-shm')
            outcome = read(STUDY / 'units' / parts[1] / 'outcome.json')
            assert outcome['status'] == 'failed'
            assert before[name] == failure['changes'][name]['actual']
            assert path.stat().st_size == (0 if name.endswith('-wal') else 32768)
            stat = path.stat()
            moves.append({'relative_path': name, 'source': str(path), 'destination': str(destination),
                          'sha256': before[name], 'bytes': stat.st_size,
                          'mtime_ns': stat.st_mtime_ns, 'ctime_ns': stat.st_ctime_ns})
        assert len({Path(r['relative_path']).parts[1] for r in moves}) == 161
        ARCHIVE.mkdir(parents=True, exist_ok=False)
        write_once(ARCHIVE / 'MOVE-PLAN.json', {'started': started, 'moves': moves})
        for row in moves:
            source, destination = Path(row['source']), Path(row['destination'])
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists() and digest(source) == row['sha256']
            source.rename(destination)
            assert digest(destination) == row['sha256'] and not source.exists()
        after = manifest(STUDY)
        assert after == expected
        assert all(digest(Path(row['destination'])) == row['sha256'] for row in moves)
    report = {'pass': True, 'started': started, 'ended': time.time(),
              'terminal_manifest_sha256': digest(terminal_path), 'failure_manifest_sha256': digest(failure_path),
              'archive': str(ARCHIVE), 'moved_files': moves, 'original_files_restored_exact_inventory': len(after),
              'sealed_file_bytes_changed': 0, 'outcomes_changed': 0, 'new_model_requests': 0,
              'controller_lock_acquired': True, 'original_evaluator_terminal_exit_status': 1,
              'process_inspection': {'command': argv, 'stdout': process.stdout,
                                     'stderr': process.stderr, 'exit_status': process.returncode}}
    output = STAGE / 'FINAL-EVALUATION-OBSERVER-RECOVERY-001.json'
    write_once(output, report)
    assert read(output) == report
    print(json.dumps({'pass': True, 'output': str(output), 'sha256': digest(output),
                      'preserved_sidecars': len(moves), 'original_files': len(after),
                      'sealed_file_bytes_changed': 0, 'new_model_requests': 0}))


if __name__ == '__main__':
    main()
