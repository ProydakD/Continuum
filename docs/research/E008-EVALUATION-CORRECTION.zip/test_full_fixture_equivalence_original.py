"""Compare full frozen and corrected evaluations on the original absolute-path-bound sealed fixture."""
import json,shutil,sys,time
from pathlib import Path
PROJECT=Path(r"C:\Users\User\Documents\ChatGPT\ContinuumResearch\project");sys.path.insert(0,str(PROJECT))
from research.common import ROOT,digest
from research.e008_locks import read,write_once
from research.e008_evaluate import evaluate
from e008_evaluation_correction import corrected_dependencies
source=ROOT/'runs/e008-lifecycle-fixture-002';scope=ROOT/'artifacts/e008-eval-fix-fixture-002';scope.mkdir(exist_ok=False)
def manifest(root):return {p.relative_to(root).as_posix():digest(p) for p in root.rglob('*') if p.is_file() and p.name!='controller.lock'}
original=manifest(source);gold=read(source/'gold.json');started=time.time();reports={};elapsed={};copies={}
for label in ['baseline','corrected']:
 target=source;before=manifest(target);assert before==original
 tick=time.perf_counter()
 if label=='baseline':result=evaluate(target,gold,bootstrap_samples=100)
 else:
  with corrected_dependencies():result=evaluate(target,gold,bootstrap_samples=100)
 elapsed[label]=time.perf_counter()-tick
 assert before==manifest(target),'Evaluation changed original fixture evidence: '+label
 path=scope/(label+'-report.json');write_once(path,result);reports[label]=result;copies[label]={'report':str(path),'sha256':digest(path),'files_unchanged':len(before)}
assert reports['baseline']==reports['corrected'],[k for k in reports['baseline'] if reports['baseline'][k]!=reports['corrected'][k]]
assert manifest(source)==original
report={'pass':True,'started':started,'ended':time.time(),'fixture_positions':reports['baseline']['evaluated_positions'],'reports_equal_all_fields':True,'fixture_files_unchanged':len(original),'original_fixture_unchanged':True,'bootstrap_samples_for_equivalence_only':100,'elapsed_seconds':elapsed,'reports':copies,'new_model_requests':0,'new_workers':0,'scientific_inference':False,'supplement_sha256':digest(Path(__file__).with_name('e008_evaluation_correction.py'))}
output=Path(__file__).parent/'FULL-FIXTURE-EQUIVALENCE-002.json';write_once(output,report);print(json.dumps(report))
